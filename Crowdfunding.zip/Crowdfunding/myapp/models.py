from django.db import models
from user_profile.models import User
from django.utils.text import slugify
from .slugs import generate_unique_slug

# Create your models here.

class Category(models.Model):
    title = models.CharField(
        max_length = 150,
        unique = True
    )
    slug = models.SlugField(
        null = True,
        blank = True
    )
    created_date = models.DateField(
        auto_now_add = True
    )
    def __str__(self) -> str:
        return self.title

    def save(self, *args, **kwargs):
        self.slag = slugify(self.title)
        super().save(*args, **kwargs)


class Tag(models.Model):
    title = models.CharField(
        max_length = 150
    )
    slug = models.SlugField(
        null = True,
        blank = True
    )
    created_date = models.DateField(
        auto_now_add = True
    )
    def __str__(self) -> str:
        return self.title
    
    def save(self, *args, **kwargs):
        self.slag = slugify(self.title)
        super().save(*args, **kwargs)

class Blog(models.Model):
    user = models.ForeignKey(
        User,
        related_name = 'user_blogs',
        on_delete = models.CASCADE
    )
    category = models.ForeignKey(
        Category,
        related_name = 'category_blogs',
        on_delete = models.CASCADE
    )
    tags = models.ManyToManyField(
        Tag,
        related_name = 'tag_blogs',
        blank = True
    )
    title = models.CharField(
        max_length = 250,
    )
    amount = models.FloatField()
    balance = models.FloatField(
        default = 0
    )
    slug = models.SlugField(
        null = True,
        blank = True
    )
    banner = models.ImageField(
        upload_to = 'blog_banners',
        max_length = 500
    )
    description = models.TextField()
    created_date = models.DateField(
        auto_now_add = True
    )

    def __str__(self) -> str:
        return self.title
    
    def save(self, *args, **kwargs):
        self.slug = generate_unique_slug(self, self.title)
        super().save(*args, **kwargs)

    def donate(self, koto):
        self.balance = self.balance + koto
    
    def get_balance(self):
        return self.balance


class Comment(models.Model):
    user = models.ForeignKey(
        User,
        related_name = 'user_comment',
        on_delete = models.CASCADE
    )
    blog = models.ForeignKey(
        Blog,
        related_name = 'blog_comments',
        on_delete = models.CASCADE
    )
    text = models.TextField()
    created_date = models.DateField(
        auto_now_add = True
    )

    def __str__(self) -> str:
        return self.text
    
class Reply(models.Model):
    user = models.ForeignKey(
        User,
        related_name = 'user_replies',
        on_delete = models.CASCADE
    )
    comment = models.ForeignKey(
        Comment,
        related_name = 'comment_replies',
        on_delete = models.CASCADE
    )
    text = models.TextField()
    created_date = models.DateField(
        auto_now_add = True
    )

    def __str__(self) -> str:
        return self.text
    
# Gateway Integration

class Transaction(models.Model):
    name = models.CharField(max_length=150)
    slug = models.CharField(max_length=150)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    tran_id = models.CharField(max_length=15)
    val_id = models.CharField(max_length=75)
    card_type = models.CharField(max_length=150)
    card_no = models.CharField(max_length=55, null=True)
    bank_tran_id = models.CharField(max_length=155, null=True)
    status = models.CharField(max_length=55)
    tran_date = models.DateTimeField()
    currency = models.CharField(max_length=10)
    card_issuer = models.CharField(max_length=255)
    card_brand = models.CharField(max_length=15)
    card_issuer_country = models.CharField(max_length=55)
    card_issuer_country_code = models.CharField(max_length=55)
    currency_rate = models.DecimalField(max_digits=10, decimal_places=2)
    verify_sign = models.CharField(max_length=155)
    verify_sign_sha2 = models.CharField(max_length=255)
    risk_level = models.CharField(max_length=15)
    risk_title = models.CharField(max_length=25)
