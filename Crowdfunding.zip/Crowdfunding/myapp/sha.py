import hashlib

def hash(str):
    hashed_string = hashlib.sha256(str.encode('utf-8')).hexdigest()
    return hashed_string